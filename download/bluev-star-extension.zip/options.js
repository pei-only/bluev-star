(async () => {
  const S = await BV.getSettings(); const $ = id => document.getElementById(id);
  ['sidebar', 'floating', 'profile', 'pills', 'chips', 'sameTab'].forEach(k => { $(k).checked = !!S[k]; $(k).onchange = () => { S[k] = $(k).checked; BV.setSettings(S); }; });
  ['interval', 'theme'].forEach(k => { $(k).value = String(S[k]); $(k).onchange = () => { S[k] = k === 'interval' ? +$(k).value : $(k).value; BV.setSettings(S); }; });
  const show = async () => { const d = await BV.getData(); $('st').textContent = d.fetchedAt ? `上次刷新：${new Date(d.fetchedAt).toLocaleString('zh-CN')} · ${Object.keys(d.acc ? d.acc.a : {}).length} 个账号` : (d.lastError ? '加载失败：' + d.lastError : '尚未加载'); };
  $('ref').onclick = async () => { $('st').textContent = '刷新中…'; await BV.refresh(); show(); }; show();
  const ec = () => chrome.storage.local.get('errs', o => { const x = o.errs; $('ec').textContent = x && x.count ? `${x.count} 次 · 最近：${x.last}（${new Date(x.at).toLocaleString('zh-CN')}）` : '0 次，一切正常'; });
  $('ecr').onclick = () => chrome.storage.local.remove('errs', ec); ec();
})();
