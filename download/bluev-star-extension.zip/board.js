// Leaderboard widget shared by sidebar card, floating panel and popup
BV.CSS = `
:host{all:initial}
.bv{--bg:#ffffff;--fg:#0f1419;--mut:#6b7280;--line:rgba(15,20,25,.08);--soft:#f4f6fb;--acc:#2f6bff;--acc2:#8a5cff;--hot:#ff5a36;
  font:13px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","Segoe UI",sans-serif;color:var(--fg);-webkit-font-smoothing:antialiased}
.bv.dark{--bg:#15181e;--fg:#eef0f4;--mut:#8b93a1;--line:rgba(255,255,255,.08);--soft:#1e222b}
.bv *{box-sizing:border-box}
.card{background:var(--bg);border:1px solid var(--line);border-radius:18px;overflow:hidden;box-shadow:0 1px 2px rgba(0,0,0,.04),0 12px 32px -18px rgba(30,40,90,.28)}
.hd{display:flex;align-items:center;gap:8px;padding:12px 14px 8px;background:linear-gradient(135deg,rgba(47,107,255,.10),rgba(138,92,255,.10) 60%,transparent)}
.logo{width:22px;height:22px;border-radius:7px;background:linear-gradient(135deg,#2f6bff,#8a5cff);display:grid;place-items:center;color:#fff;font-size:12px;font-weight:800;box-shadow:0 4px 10px -4px #5a5cff}
.ttl{font-weight:800;font-size:15px;letter-spacing:.2px}
.sub{color:var(--mut);font-size:11px;margin-left:auto;white-space:nowrap}
.ib{border:0;background:transparent;color:var(--mut);cursor:pointer;font-size:14px;border-radius:8px;padding:2px 6px}.ib:hover{background:var(--soft);color:var(--fg)}
.tabs{display:flex;gap:4px;padding:4px 12px 0}
.tab{flex:1;border:0;cursor:pointer;padding:7px 0;border-radius:10px;background:transparent;color:var(--mut);font:inherit;font-weight:700}
.tab.on{background:var(--soft);color:var(--fg)}
.seg{display:flex;gap:4px;padding:8px 12px 0;flex-wrap:wrap;align-items:center}
.pill{border:1px solid var(--line);background:var(--bg);color:var(--mut);border-radius:999px;padding:3px 10px;font:inherit;font-size:12px;cursor:pointer;white-space:nowrap}
.pill.on{color:#fff;border-color:transparent;background:linear-gradient(135deg,var(--acc),var(--acc2));box-shadow:0 4px 12px -6px #5a5cff}
.sp{flex:1}
.seg .pill{padding:3px 8px;font-size:11.5px}
.nis{max-width:100%}
.nis{display:flex;gap:4px;overflow-x:auto;padding:8px 12px 2px;scrollbar-width:none}.nis::-webkit-scrollbar{display:none}
.nis .pill{font-size:11.5px;padding:2px 9px}
.list{padding:4px 6px 6px}
.row{display:flex;gap:10px;align-items:flex-start;padding:8px 8px;border-radius:12px;text-decoration:none;color:inherit;cursor:pointer}
.row:hover{background:var(--soft)}
.row.act{background:linear-gradient(135deg,rgba(47,107,255,.12),rgba(138,92,255,.12));box-shadow:inset 3px 0 0 var(--acc)}
.rk{width:18px;flex:none;text-align:center;font-weight:800;color:var(--mut);font-size:12px;padding-top:9px}
.row:nth-child(1) .rk{color:#f5a524}.row:nth-child(2) .rk{color:#9aa4b2}.row:nth-child(3) .rk{color:#c9834a}
.av{width:36px;height:36px;border-radius:50%;flex:none;object-fit:cover;background:linear-gradient(135deg,#dbe4ff,#eadcff);box-shadow:0 0 0 2px var(--bg),0 0 0 3px var(--line)}
.mid{min-width:0;flex:1}
.nm{display:flex;gap:6px;align-items:center;min-width:0}
.nm b{font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pl{cursor:pointer;min-width:0;overflow:hidden;display:flex}.pl:hover b{text-decoration:underline}
.hn{color:var(--mut);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tx{color:var(--fg);opacity:.86;font-size:12.5px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-top:1px}
.meta{display:flex;gap:8px;margin-top:3px;color:var(--mut);font-size:11.5px;flex-wrap:wrap}
.chip{display:inline-flex;align-items:center;gap:3px;background:var(--soft);border-radius:999px;padding:1px 7px;font-size:11px;color:var(--mut);white-space:nowrap}
.gain{flex:none;text-align:right;font-weight:800;color:var(--hot);font-size:13px;padding-top:2px;white-space:nowrap}
.gain small{display:block;font-weight:500;color:var(--mut);font-size:11px}
.empty{padding:22px 16px;text-align:center;color:var(--mut)}
.empty .big{font-size:26px}
.eta{margin:10px 12px 4px;padding:12px;border-radius:14px;background:var(--soft);color:var(--mut);font-size:12px}
.eta b{color:var(--fg)}
.pill.em{opacity:.5;border-style:dashed}.pill.em.on{opacity:.8}
.ft{display:flex;align-items:center;justify-content:space-between;padding:8px 14px 12px;border-top:1px solid var(--line);font-size:12px}
.ft a{color:var(--acc);text-decoration:none;font-weight:700}.ft a:hover{text-decoration:underline}
.more{display:block;width:calc(100% - 12px);margin:2px 6px 4px;padding:7px;border:0;border-radius:10px;background:transparent;color:var(--acc);font:inherit;font-weight:700;cursor:pointer}.more:hover{background:var(--soft)}
`;
BV.CSS += BV.ACC_CSS;
BV.board = function (root, opts) {
  const st = opts.state || {}; for (const [k, v] of Object.entries({kind: 'vel', win: '30m', metric: 'dviews', gwin: '3d', niches: new Set(), q: '', limit: opts.limit || 5, expanded: false, active: ''})) if (!(k in st)) st[k] = v;
  let D = {}, favs = new Set();
  const loadFavs = () => { try { BV.getFavs().then(f => { favs = new Set(f); paintS(); }); } catch (e) {} };
  function paintS() { const box = host.querySelector('.sres'); if (!box) return; const q = st.q.trim(); if (!q) { box.innerHTML = ''; return; }
    const r = BV.search(D, q, 3); box.innerHTML = r.length ? r.map(a => BV.accHTML(D, a, favs.has(a.handle.toLowerCase()))).join('') : '<div class="empty" style="padding:10px">没找到这个账号（可能还没收录）</div>'; }
  const host = document.createElement('div'); host.className = 'bv' + (opts.dark ? ' dark' : ''); root.appendChild(host);
  const W = {'30m': '30分钟', '1h': '1小时', '3h': '3小时', '5h': '5小时'}, G = {'3d': 3, '5d': 5, '10d': 10, '15d': 15, '30d': 30};
  function rowsFor() {
    let b = st.kind === 'vel' ? (D.vel && D.vel.boards || {})[st.win] : (D.gro && D.gro.boards || {})[st.gwin];
    if (!b) return null;
    if (st.niches.size) b = b.filter(r => st.niches.has(r.niche || '其他'));
    if (st.kind === 'vel') b = b.slice().sort((x, y) => (y[st.metric] - x[st.metric]));
    return b;
  }
  const vHas = k => !!((D.vel && D.vel.boards || {})[k] || []).length;
  const MIN = {'30m': 30, '1h': 60, '3h': 180, '5h': 300};
  function vEta(k) { const e = D.vel && D.vel.eta && D.vel.eta[k], f = D.vel && D.vel.day_first; const t = e ? new Date(e) : f ? new Date(Date.parse(f) + MIN[k] * 6e4) : null; if (!t || isNaN(t)) return '';
    const o = {timeZone: 'Asia/Shanghai'}, hm = t.toLocaleTimeString('zh-CN', {...o, hour: '2-digit', minute: '2-digit', hour12: false}), now = new Date(BV.now ? BV.now() : Date.now());
    return (t.toLocaleDateString('zh-CN', o) === now.toLocaleDateString('zh-CN', o) ? '' : t > now ? '明天 ' : '') + hm; }
  function autoWin() { if (st.winUser || !D.vel || vHas(st.win)) return; const f = Object.keys(W).find(vHas); if (f) st.win = f; }
  function niches() { const a = D.acc; if (!a) return []; return a.niches.map((n, i) => [n, a.niche_counts[i]]); }
  function render() {
    autoWin(); const acc = D.acc, rows = rowsFor(); const lim = st.expanded ? (opts.maxLimit || 30) : st.limit;
    let h = `<div class="card"><div class="hd"><div class="logo">V</div><div class="ttl">蓝V星图</div><div class="sub">${st.kind === 'vel' ? (D.vel && D.vel.latest ? '采样 ' + BV.ago(D.vel.latest) : '') : ''}</div>${opts.onCollapse ? '<button class="ib" data-a="collapse" title="收起">—</button>' : ''}</div>
    <div class="fresh">${BV.freshHTML(D)}</div>
    <div class="srch"><input class="sq" placeholder="搜 @账号 或名字，看排名" value="${BV.esc(st.q)}" autocomplete="off"><button class="pill" data-a="me">查我的排名</button></div><div class="sres"></div>
    <div class="tabs"><button class="tab ${st.kind === 'vel' ? 'on' : ''}" data-a="kind" data-v="vel">🔥 内容涨速</button><button class="tab ${st.kind === 'gro' ? 'on' : ''}" data-a="kind" data-v="gro">📈 涨粉榜</button></div>`;
    if (st.kind === 'vel') h += `<div class="seg">${Object.keys(W).map(k => `<button class="pill ${st.win === k ? 'on' : ''}${D.vel && !vHas(k) ? ' em' : ''}" data-a="win" data-v="${k}"${D.vel && !vHas(k) ? ` title="数据积累中${vEta(k) ? '，预计 ' + vEta(k) + ' 后出榜' : ''}"` : ''}>${W[k]}</button>`).join('')}<span class="sp"></span><button class="pill ${st.metric === 'dviews' ? 'on' : ''}" data-a="metric" data-v="dviews">浏览</button><button class="pill ${st.metric === 'dlikes' ? 'on' : ''}" data-a="metric" data-v="dlikes">点赞</button></div>`;
    else h += `<div class="seg">${Object.keys(G).map(k => `<button class="pill ${st.gwin === k ? 'on' : ''}" data-a="gwin" data-v="${k}">${G[k]}日</button>`).join('')}</div>`;
    h += `<div class="nis"><button class="pill ${st.niches.size ? '' : 'on'}" data-a="nall">全部</button>${niches().map(([n]) => `<button class="pill ${st.niches.has(n) ? 'on' : ''}" data-a="ni" data-v="${BV.esc(n)}">${BV.esc(BV.ni(n))}</button>`).join('')}</div>`;
    if (!acc) h += `<div class="empty"><div class="big">⏳</div>正在加载榜单数据…</div>`;
    else if (!rows) {
      if (st.kind === 'gro') { const first = D.gro && D.gro.first; const d = G[st.gwin]; const eta = first ? new Date(new Date(first).getTime() + d * 864e5) : null;
        h += `<div class="eta">📊 <b>${d}日涨粉榜</b>正在积累每日粉丝快照<br>${eta ? `预计 <b>${eta.getMonth() + 1}月${eta.getDate()}日</b> 晚上开始有数据` : '快照开始后约 ' + d + ' 天出榜'}。不放假数据。</div>`; }
      else { const eta = vEta(st.win), alt = Object.keys(W).filter(vHas).map(k => W[k]);
        h += `<div class="eta">🕐 <b>该时间窗口数据积累中</b>，${eta ? `预计 <b>${eta}</b> 后出榜（北京时间）` : '稍后出榜'}<br>${W[st.win]}榜需要当天相隔约${W[st.win]}的两次采样，夜间不采样、不跨夜拼接。${alt.length ? `<br>现在可看：${alt.map(a => `<button class="pill" data-a="win" data-v="${Object.keys(W).find(k => W[k] === a)}" style="margin:6px 4px 0 0">${a}</button>`).join('')}` : ''}</div>`; }
    } else if (!rows.length) h += `<div class="empty">所选方向暂时没有上榜内容</div>`;
    else {
      h += '<div class="list">' + rows.slice(0, lim).map((r, i) => {
        const av = BV.small(r.avatar || '');
        const prof = 'https://x.com/' + encodeURIComponent(r.handle);
        if (st.kind === 'vel') { const v = st.metric === 'dviews' ? r.dviews : r.dlikes;
          return `<div class="row${BV.isActive(st, prof + '/status/' + r.id) ? ' act' : ''}" data-href="${prof}/status/${BV.esc(r.id)}" title="打开原帖"><div class="rk">${i + 1}</div>${av ? `<img class="av" src="${BV.esc(av)}" loading="lazy" referrerpolicy="no-referrer">` : '<div class="av"></div>'}<div class="mid"><div class="nm"><span class="pl" data-href="${prof}" title="打开主页"><b>${BV.esc(r.name || r.handle)}</b></span><span class="hn">@${BV.esc(r.handle)}</span></div><div class="tx">${BV.esc((r.text || '').replace(/https?:\/\/t\.co\/\S*/g, '').trim())}</div><div class="meta"><span class="chip">${BV.esc(BV.ni(r.niche))}</span><span>👁 ${BV.fmt(r.views)}</span><span>♥ ${BV.fmt(r.likes)}</span></div></div><div class="gain">+${BV.fmt(v)}<small>${st.metric === 'dviews' ? '浏览' : '点赞'}/${W[st.win]}</small></div></div>`; }
        return `<div class="row${BV.isActive(st, prof) ? ' act' : ''}" data-href="${prof}" title="打开主页"><div class="rk">${i + 1}</div>${av ? `<img class="av" src="${BV.esc(av)}" loading="lazy" referrerpolicy="no-referrer">` : '<div class="av"></div>'}<div class="mid"><div class="nm"><b>${BV.esc(r.name || r.handle)}</b><span class="hn">@${BV.esc(r.handle)}</span></div><div class="meta"><span class="chip">${BV.esc(BV.ni(r.niche))}</span><span>粉丝 ${BV.fmt(r.followers)}</span></div></div><div class="gain">+${BV.fmt(r.gain)}<small>${r.pct != null ? r.pct + '%' : ''}</small></div></div>`;
      }).join('') + '</div>';
      if (rows.length > lim) h += `<button class="more" data-a="more">显示更多（共 ${rows.length} 条）</button>`;
      else if (st.expanded && st.limit < rows.length) h += `<button class="more" data-a="less">收起</button>`;
    }
    h += `<div class="ft"><span style="color:var(--mut)">${acc ? BV.fmt(Object.keys(acc.a).length) + ' 个中文蓝V' : ''}</span><a href="${BV.SITE}" target="_blank" rel="noopener">打开蓝V星图 ↗</a></div></div>`;
    host.innerHTML = h; paintS();
  }
  host.addEventListener('click', e => {
    const fv = e.target.closest('[data-fav]'); if (fv) { e.preventDefault(); e.stopPropagation(); BV.toggleFav(fv.dataset.fav).then(loadFavs); return; }
    if (e.target.closest('.sq')) return;
    const t = e.target.closest('[data-a]');
    if (!t) { const l = e.target.closest('[data-href]'); if (l) { e.preventDefault(); e.stopPropagation(); const nt = e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1; if (!nt && opts.navigate) { st.active = l.dataset.href; opts.navigate(l.dataset.href); render(); } else window.open(l.dataset.href, '_blank', 'noopener'); } return; }
    const a = t.dataset.a, v = t.dataset.v;
    e.preventDefault();
    if (a === 'kind') st.kind = v; else if (a === 'win') { st.win = v; st.winUser = true; } else if (a === 'metric') st.metric = v; else if (a === 'gwin') st.gwin = v;
    else if (a === 'nall') st.niches.clear(); else if (a === 'ni') st.niches.has(v) ? st.niches.delete(v) : st.niches.add(v);
    else if (a === 'more') st.expanded = true; else if (a === 'less') st.expanded = false; else if (a === 'collapse') return opts.onCollapse(); else if (a === 'me') st.q = BV.OWNER;
    if (opts.onState) opts.onState({niches: [...st.niches]});
    render();
  });
  host.addEventListener('input', e => { if (e.target.classList.contains('sq')) { st.q = e.target.value; paintS(); } });
  host.addEventListener('keydown', e => e.stopPropagation()); // keep X keyboard shortcuts from firing while typing
  host.addEventListener('auxclick', e => { const l = e.button === 1 && e.target.closest('[data-href]'); if (l) { e.preventDefault(); window.open(l.dataset.href, '_blank', 'noopener'); } });
  host.addEventListener('mousedown', e => { if (e.button === 1 && e.target.closest('[data-href]')) e.preventDefault(); });
  return {render, st, set(d) { D = d; render(); loadFavs(); }, dark(x) { host.classList.toggle('dark', !!x); }, el: host};
};

BV.isActive = (st, href) => { if (!st.active) return false; const a = st.active.toLowerCase().replace(/\/$/, ''), h = href.toLowerCase(); return a === h; };
