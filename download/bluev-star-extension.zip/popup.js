async function go(url) {
  const [t] = await chrome.tabs.query({active: true, currentWindow: true});
  if (t && /^https:\/\/(x|twitter)\.com\//.test(t.url || '')) {
    try { await chrome.tabs.sendMessage(t.id, {type: 'navigate', url}); } catch (e) { await chrome.tabs.update(t.id, {url}); }
  } else if (t) await chrome.tabs.update(t.id, {url}); else await chrome.tabs.create({url});
  window.close();
}
(async () => {
  const $ = s => document.querySelector(s); const S = await BV.getSettings();
  const dark = S.theme === 'dark' || (S.theme === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.classList.toggle('dark', dark);
  const shadow = $('#board').attachShadow({mode: 'open'}); const st = document.createElement('style'); st.textContent = BV.CSS + '.card{box-shadow:none}#x,.bv .card>.fresh{display:none}'; shadow.appendChild(st);
  const b = BV.board(shadow, {limit: 30, maxLimit: 100, dark, state: {niches: new Set(S.niches || [])}, navigate: S.sameTab ? go : null, onState: x => { S.niches = x.niches; BV.setSettings(S); }});
  let D = await BV.getData(); let qn = new Set(); let favs = new Set(await BV.getFavs());
  const fsh = $('#favs').attachShadow({mode: 'open'}); const fst = document.createElement('style'); fst.textContent = BV.CSS + '.card{box-shadow:none}'; fsh.appendChild(fst); const fbox = document.createElement('div'); fbox.className = 'bv' + (dark ? ' dark' : ''); fsh.appendChild(fbox);
  function paintFavs() { const list = [...favs].map(h => BV.lookup(D.acc, h)).filter(Boolean);
    fbox.innerHTML = `<div class="card"><div class="hd"><div class="logo">★</div><div class="ttl">我的收藏</div><div class="sub">${list.length} 个账号 · 仅保存在本机</div></div><div class="list">${list.length ? list.map(a => BV.accHTML(D, a, true)).join('') : '<div class="empty"><div class="big">☆</div>在榜单搜索或“找博主”里点 ☆ 收藏账号</div>'}</div></div>`; }
  fbox.addEventListener('click', async e => { const f = e.target.closest('[data-fav]'); if (f) { e.preventDefault(); await BV.toggleFav(f.dataset.fav); favs = new Set(await BV.getFavs()); paintFavs(); return; } const l = e.target.closest('[data-href]'); if (l) { e.preventDefault(); (S.sameTab && !e.ctrlKey && !e.metaKey ? go : u => chrome.tabs.create({url: u}))(l.dataset.href); } });
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.favs) { favs = new Set(c.favs.newValue || []); paintFavs(); if (!$('#search').hidden) search(); } });
  chrome.storage.local.get('errs', o => { const x = o.errs; if (x && x.count) $('#errs').textContent = `页面嵌入异常 ${x.count} 次（已静默处理，详情见设置）`; });
  function paint() { b.set(D); $('#fresh').innerHTML = BV.freshHTML(D); paintFavs(); $('#sub').textContent = D.acc ? `${BV.fmt(Object.keys(D.acc.a).length)} 个中文蓝V` : (D.lastError ? '加载失败：' + D.lastError : '正在加载…');
    if (D.acc) { $('#sn').innerHTML = `<button class="pill ${qn.size ? '' : 'on'}" data-n="">全部</button>` + D.acc.niches.map(n => `<button class="pill ${qn.has(n) ? 'on' : ''}" data-n="${BV.esc(n)}">${BV.esc(BV.ni(n))}</button>`).join(''); search(); } }
  let all = null;
  function search() { if (!D.acc) return; if (!all) all = Object.keys(D.acc.a).map(k => BV.lookup(D.acc, k)).sort((x, y) => y.followers - x.followers);
    const q = $('#q').value.trim().toLowerCase().replace(/^@/, '');
    const r = all.filter(a => (!qn.size || qn.has(a.niche)) && (!q || a.handle.toLowerCase().includes(q) || a.name.toLowerCase().includes(q) || a.niche.includes(q) || a.tags.some(t => t.toLowerCase().includes(q)))).slice(0, 60);
    $('#res').innerHTML = r.length ? r.map(a => `<a class="u" href="https://x.com/${encodeURIComponent(a.handle)}" target="_blank">${a.avatar ? `<img src="${BV.esc(BV.small(a.avatar))}" loading="lazy">` : '<div class="ph"></div>'}<div class="m"><b>${BV.esc(a.name)}${a.owner ? ' ⭐' : ''}</b><div class="h">@${BV.esc(a.handle)}</div><div><span class="c">${BV.esc(BV.ni(a.niche))}</span><span class="c">#${a.rank}</span><span class="c">${BV.esc(a.vtype)}</span>${BV.ranks(D, a.handle).slice(0, 2).map(x => `<span class="c hot">${x.board} #${x.rank}</span>`).join('')}</div></div><div class="f">${BV.fmt(a.followers)}<small>粉丝</small></div><button class="st${favs.has(a.handle.toLowerCase()) ? ' on' : ''}" data-fav="${BV.esc(a.handle)}" title="收藏">${favs.has(a.handle.toLowerCase()) ? '★' : '☆'}</button></a>`).join('') : '<div class="hint">没有找到匹配的博主</div>'; }
  $('#q').addEventListener('input', search);
  $('#res').addEventListener('click', async e => { const f = e.target.closest('[data-fav]'); if (f) { e.preventDefault(); await BV.toggleFav(f.dataset.fav); favs = new Set(await BV.getFavs()); search(); paintFavs(); return; } const a = e.target.closest('a.u'); if (!a || !S.sameTab || e.ctrlKey || e.metaKey || e.shiftKey || e.button) return; e.preventDefault(); go(a.href); });
  $('#sn').addEventListener('click', e => { const t = e.target.closest('[data-n]'); if (!t) return; const n = t.dataset.n; if (!n) qn.clear(); else qn.has(n) ? qn.delete(n) : qn.add(n); paint(); });
  document.querySelectorAll('nav button').forEach(x => x.onclick = () => { document.querySelectorAll('nav button').forEach(y => y.classList.toggle('on', y === x)); ['board', 'search', 'favs'].forEach(p => $('#' + p).hidden = x.dataset.p !== p); if (x.dataset.p === 'search') $('#q').focus(); });
  $('#opt').onclick = () => chrome.runtime.openOptionsPage();
  $('#theme').onclick = async () => { const d = !document.documentElement.classList.contains('dark'); document.documentElement.classList.toggle('dark', d); b.dark(d); S.theme = d ? 'dark' : 'light'; await BV.setSettings(S); };
  $('#ref').onclick = async () => { $('#ref').textContent = '…'; await BV.refresh(); D = await BV.getData(); all = null; paint(); $('#ref').textContent = '↻'; };
  paint(); if (!D.acc || Date.now() - (D.fetchedAt || 0) > 5 * 60000) { await BV.refresh(); D = await BV.getData(); all = null; paint(); }
})();
