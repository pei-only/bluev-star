importScripts('shared.js');
async function pull() {
  const get = async n => { const r = await fetch(BV.DATA + n + '?t=' + Date.now(), {cache: 'no-store'}); if (!r.ok) throw new Error(n + ' HTTP ' + r.status); return r.json(); };
  try {
    const [acc, vel, gro] = await Promise.all([get('ext_accounts.json'), get('ext_velocity.json'), get('ext_growth.json')]);
    await chrome.storage.local.set({acc, vel, gro, fetchedAt: Date.now(), lastError: ''});
    return {ok: true};
  } catch (e) { await chrome.storage.local.set({lastError: String(e && e.message || e)}); return {ok: false, error: String(e)}; }
}
async function schedule() { const s = await BV.getSettings(); chrome.alarms.create('refresh', {periodInMinutes: Math.max(720, +s.interval || 1440)}); }
chrome.runtime.onInstalled.addListener(() => { schedule(); pull(); });
chrome.runtime.onStartup.addListener(() => { schedule(); pull(); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'refresh') pull(); });
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.settings) schedule(); });
chrome.runtime.onMessage.addListener((m, _s, reply) => {
  if (m && m.type === 'refresh') { pull().then(reply); return true; }
  if (m && m.type === 'ensure') { chrome.storage.local.get('fetchedAt', o => { if (!o.fetchedAt || Date.now() - o.fetchedAt > 5 * 60000) pull().then(reply); else reply({ok: true, cached: true}); }); return true; }
});
