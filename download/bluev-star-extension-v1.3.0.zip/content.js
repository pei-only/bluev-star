// 蓝V星图 content script — additive, Shadow-DOM isolated, never modifies X's own nodes' content.
(() => {
  if (window.__bvLoaded) return; window.__bvLoaded = true;
  let S = Object.assign({}, BV.DEFAULTS), D = {}, cardState = null, panelScroll = 0, sidebar = null, floatEl = null, floatCollapsed = true;
  const SEL = {
    side: ['[data-testid="sidebarColumn"]', 'main [role="complementary"]', 'div[aria-label="Trending"]', 'div[aria-label="趋势"]'],
    search: ['[data-testid="SearchBox_Search_Input"]', 'form[role="search"]', 'input[type="search"]'],
    primary: ['[data-testid="primaryColumn"]', 'main [role="main"]', 'main'],
    userName: ['[data-testid="UserName"]', '[data-testid="UserDescription"]', '[data-testid="UserProfileHeader_Items"]'],
    tweet: ['article[data-testid="tweet"]', 'article[role="article"]', 'article'],
    authorName: ['[data-testid="User-Name"]', 'a[role="link"][href^="/"] div[dir]']
  };
  const safe = (where, f) => { try { f(); } catch (e) { BV.logErr(where, e); } };
  const done = new WeakMap(); // article -> key processed
  const RESERVED = new Set(['home', 'explore', 'notifications', 'messages', 'i', 'settings', 'search', 'compose', 'login', 'logout', 'signup', 'tos', 'privacy', 'jobs', 'grok', 'communities', 'premium_sign_up', 'hashtag', 'lists', 'bookmarks', 'intent', 'share', 'account']);
  const isDark = () => { const c = getComputedStyle(document.body).backgroundColor.match(/\d+/g); return c ? (+c[0] + +c[1] + +c[2]) < 200 : false; };
  const PILL_CSS = `:host{all:initial;display:inline-flex;vertical-align:middle}
  .p{display:inline-flex;align-items:center;gap:3px;margin-left:6px;padding:1px 8px;border-radius:999px;font:700 11.5px/18px -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#fff;background:linear-gradient(135deg,#ff7a2f,#ff3d6e);box-shadow:0 3px 10px -4px rgba(255,70,80,.7);white-space:nowrap;cursor:pointer;text-decoration:none}
  .c{display:inline-flex;align-items:center;margin-left:4px;padding:0 6px;border-radius:999px;font:500 10.5px/16px -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#536471;background:rgba(83,100,113,.10);white-space:nowrap;opacity:.9;text-decoration:none}
  .dark .c{color:#a9b4bf;background:rgba(255,255,255,.08)}`;
  function shadowHost(tag, css, cls) { const h = document.createElement(tag || 'bv-star'); h.setAttribute('data-bv', cls || ''); const r = h.attachShadow({mode: 'open'}); const s = document.createElement('style'); s.textContent = css; r.appendChild(s); return [h, r]; }

  function getState() { if (!cardState) cardState = {niches: new Set(S.niches || [])}; return cardState; }
  const nav = () => S.sameTab ? (url => BV.spaNavigate(url)) : null;
  function syncActive() { if (!cardState) return; const cur = 'https://x.com' + location.pathname.replace(/\/$/, '');
    if (cardState.active && cardState.active.toLowerCase() !== cur.toLowerCase()) { cardState.active = ''; }
    if (!cardState.active) { cardState.active = cur; }
    if (sidebar) sidebar.b.render(); if (floatEl && floatEl._b) floatEl._b.render(); }
  // ---------- 1. sidebar card / floating panel ----------
  function mountSidebar() {
    let col = BV.q(document, SEL.side); if (col && col.getAttribute('data-testid') !== 'sidebarColumn') { while (col.parentElement && col.parentElement.tagName !== 'MAIN' && col.parentElement.children.length === 1) col = col.parentElement; }
    if (!S.sidebar) { if (sidebar) { sidebar.h.remove(); sidebar = null; } if (floatEl) { floatEl.remove(); floatEl = null; } return; }
    if (col) {
      if (floatEl) { floatEl.remove(); floatEl = null; }
      if (sidebar && col.contains(sidebar.h)) return;
      // find container that holds the stacked sidebar modules (search, trends, who-to-follow)
      let box = col; for (let i = 0; i < 8 && box.children.length === 1; i++) box = box.children[0];
      const search = BV.q(box, SEL.search);
      let anchor = null; if (search) { anchor = search; while (anchor.parentElement && anchor.parentElement !== box) anchor = anchor.parentElement; if (anchor.parentElement !== box) anchor = null; }
      const [h, r] = shadowHost('bv-star', BV.CSS, 'sidebar'); h.style.cssText = 'display:block;margin:12px 0 16px;position:relative;z-index:1';
      // if search box is sticky, X places modules below it; insert after it, else at top
      if (anchor && anchor.nextSibling) box.insertBefore(h, anchor.nextSibling); else box.insertBefore(h, box.firstChild);
      const b = BV.board(r, {limit: 5, maxLimit: 30, dark: isDark(), state: getState(), navigate: nav(), onState: x => { S.niches = x.niches; BV.setSettings(S); }});
      sidebar = {h, b}; b.set(D);
    } else if (S.floating) {
      if (sidebar) { sidebar.h.remove(); sidebar = null; }
      if (floatEl && document.documentElement.contains(floatEl)) return;
      const [h, r] = shadowHost('bv-star', BV.CSS + `.fab{position:fixed;right:16px;bottom:84px;width:46px;height:46px;border-radius:16px;border:0;cursor:pointer;color:#fff;font:800 18px sans-serif;background:linear-gradient(135deg,#2f6bff,#8a5cff);box-shadow:0 10px 28px -8px rgba(70,80,255,.7);z-index:2147483000}.panel{position:fixed;right:16px;bottom:84px;width:min(360px,calc(100vw - 32px));max-height:70vh;overflow:auto;border-radius:18px;z-index:2147483000}`, 'float');
      floatEl = h; document.documentElement.appendChild(h);
      const fab = document.createElement('button'); fab.className = 'fab'; fab.textContent = 'V'; fab.title = '蓝V星图榜单';
      const panel = document.createElement('div'); panel.className = 'panel';
      r.appendChild(fab); r.appendChild(panel);
      panel.addEventListener('scroll', () => { panelScroll = panel.scrollTop; }, {passive: true});
      const b = BV.board(panel, {limit: 6, maxLimit: 30, dark: isDark(), state: getState(), navigate: nav(), onCollapse: () => { floatCollapsed = true; sync(); }, onState: x => { S.niches = x.niches; BV.setSettings(S); }});
      const sync = () => { panel.style.display = floatCollapsed ? 'none' : 'block'; fab.style.display = floatCollapsed ? 'block' : 'none'; };
      fab.onclick = () => { floatCollapsed = false; sync(); panel.scrollTop = panelScroll; }; sync();
      floatEl._b = b; b.set(D);
    }
  }

  // ---------- 2. profile badge ----------
  function profileHandle() { const seg = location.pathname.split('/').filter(Boolean); if (!seg.length || seg.length > 2 && seg[1] !== 'with_replies') return null; if (seg[1] && !['with_replies', 'media', 'likes', 'highlights', 'articles', 'superfollows', 'affiliates', 'verified_followers'].includes(seg[1])) return null; return RESERVED.has(seg[0].toLowerCase()) ? null : seg[0]; }
  const BADGE_CSS = `:host{all:initial;display:block}
  .b{margin:10px 0 2px;padding:10px 12px;border-radius:14px;border:1px solid rgba(47,107,255,.18);background:linear-gradient(135deg,rgba(47,107,255,.07),rgba(138,92,255,.07));font:13px/1.45 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#0f1419;display:flex;flex-wrap:wrap;gap:6px 8px;align-items:center}
  .dark .b{color:#eef0f4;border-color:rgba(138,92,255,.28)}
  .lg{display:inline-flex;align-items:center;gap:6px;font-weight:800}.lg i{width:18px;height:18px;border-radius:6px;background:linear-gradient(135deg,#2f6bff,#8a5cff);color:#fff;font:800 10px/18px sans-serif;text-align:center;font-style:normal}
  .k{display:inline-flex;gap:4px;align-items:center;padding:2px 9px;border-radius:999px;background:rgba(255,255,255,.75);font-size:12px;white-space:nowrap}
  .dark .k{background:rgba(255,255,255,.07)}
  .k b{font-weight:800}.up{color:#e8462f}.mut{color:#6b7280}
  .t{font-size:11.5px;color:#5b6573}.dark .t{color:#9aa4b2}
  a{margin-left:auto;color:#2f6bff;text-decoration:none;font-weight:700;font-size:12px;white-space:nowrap}a:hover{text-decoration:underline}`;
  let badge = null;
  function mountProfile() {
    const h = S.profile && profileHandle(); const info = h && BV.lookup(D.acc, h);
    const un = info && (() => { const p = BV.q(document, SEL.primary); return p && BV.q(p, SEL.userName); })();
    if (!un) { if (badge && (!info || !S.profile)) { badge.remove(); badge = null; } return; }
    if (badge && badge.dataset.h === info.handle.toLowerCase() && un.parentElement && un.parentElement.contains(badge)) return;
    if (badge) badge.remove();
    const [host, r] = shadowHost('bv-star', BADGE_CSS, 'profile'); host.dataset.h = info.handle.toLowerCase();
    const g = info.growth, gs = ['3d', '5d', '10d'].map(k => g[k] != null ? `<span class="k">${k.replace('d', '日')} <b class="up">+${BV.fmt(g[k])}</b></span>` : '').join('');
    const w = document.createElement('div'); w.className = isDark() ? 'dark' : '';
    w.innerHTML = `<div class="b"><span class="lg"><i>V</i>蓝V星图</span><span class="k">${BV.esc(BV.ni(info.niche))}</span><span class="k">方向排名 <b>#${info.rank}</b>${info.nicheTotal ? `<span class="mut">/${info.nicheTotal}</span>` : ''}</span><span class="k">${BV.esc(info.vtype)}</span>${info.owner ? '<span class="k">⭐ 站长</span>' : ''}${gs || '<span class="k mut">涨粉数据积累中</span>'}${info.tags.length ? `<span class="t">${info.tags.map(t => '#' + BV.esc(t)).join(' ')}</span>` : ''}<a href="${BV.siteLink(info.handle)}" target="_blank" rel="noopener">在蓝V星图查看 ↗</a></div>`;
    r.appendChild(w); un.after(host); badge = host;
  }

  // ---------- 3. post pills + author chips ----------
  let velIdx = new Map();
  function buildVelIdx() { velIdx = new Map(); const b = {}; /* v1.3.0 velocity hidden */ for (const [win, label] of [['5h', '5小时'], ['3h', '3小时'], ['1h', '1小时'], ['30m', '30分钟']]) for (const r of b[win] || []) velIdx.set(String(r.id), {win: label, dv: r.dviews, dl: r.dlikes}); }
  function statusId(art) { const t = art.querySelector('a[href*="/status/"] time'); const a = t ? t.closest('a') : art.querySelector('a[href*="/status/"]'); const m = a && a.getAttribute('href').match(/\/([^/]+)\/status\/(\d+)/); return m ? {h: m[1], id: m[2], a} : null; }
  function scanTweets(root) {
    if (!S.pills && !S.chips) return;
    const arts = BV.qa((root && root.querySelectorAll ? root : document), SEL.tweet);
    const dark = isDark();
    for (const art of arts) { try {
      const s = statusId(art); if (!s) continue; const key = s.id + '|' + S.pills + S.chips + (D.fetchedAt || 0);
      if (done.get(art) === key) continue;
      art.querySelectorAll(':scope bv-star[data-bv="pill"],:scope bv-star[data-bv="chip"]').forEach(x => { if (x.closest('article') === art) x.remove(); });
      done.set(art, key);
      const v = S.pills && velIdx.get(s.id);
      if (v) { const [h, r] = shadowHost('bv-star', PILL_CSS, 'pill'); const w = document.createElement('span'); w.className = dark ? 'dark' : '';
        w.innerHTML = `<span class="p" title="蓝V星图：${v.win}内 +${v.dv} 浏览 / +${v.dl} 点赞">🔥 涨速 +${BV.fmt(v.dv)}浏览/${v.win}</span>`; r.appendChild(w);
        const tw = s.a.parentElement; (tw && tw.parentElement ? tw : s.a).after(h); }
      if (S.chips) { const info = BV.lookup(D.acc, s.h); const un = BV.q(art, SEL.authorName);
        if (info && un) { const [h, r] = shadowHost('bv-star', PILL_CSS, 'chip'); const w = document.createElement('span'); w.className = dark ? 'dark' : '';
          w.innerHTML = `<span class="c" title="蓝V星图 · ${BV.esc(info.niche)} 方向排名 #${info.rank}">${BV.esc(BV.ni(info.niche))}</span>`; r.appendChild(w);
          const first = un.firstElementChild; (first || un).appendChild(h); } }
    } catch (e) { BV.logErr('tweet', e); } }
  }

  // ---------- loop ----------
  let t = null, lastPath = location.pathname;
  function tick() { t = null; if (location.pathname !== lastPath) { lastPath = location.pathname; safe('nav', syncActive); } safe('sidebar', mountSidebar); safe('profile', mountProfile); safe('tweets', () => scanTweets()); }
  const schedule = () => { if (!t) t = setTimeout(tick, 250); };
  new MutationObserver(muts => { for (const m of muts) { for (const n of m.addedNodes) if (n.nodeType === 1 && n.tagName !== 'BV-STAR') return schedule(); for (const n of m.removedNodes) if (n.nodeType === 1 && n.tagName !== 'BV-STAR') return schedule(); } }).observe(document.documentElement, {childList: true, subtree: true});
  async function load() { S = await BV.getSettings(); D = await BV.getData(); buildVelIdx(); if (sidebar) sidebar.b.set(D); if (floatEl && floatEl._b) floatEl._b.set(D); if (badge) { badge.remove(); badge = null; } schedule(); }
  chrome.storage.onChanged.addListener((c, a) => { if (a !== 'local') return; if (c.settings) { const old = S; BV.getSettings().then(s => { const strip = o => JSON.stringify(Object.assign({}, o, {niches: 0})); if (strip(old) === strip(s)) { S = s; return; } S = s; if (old.sidebar !== s.sidebar || old.floating !== s.floating || old.sameTab !== s.sameTab) { if (sidebar) sidebar.h.remove(); sidebar = null; if (floatEl) floatEl.remove(); floatEl = null; } document.querySelectorAll('bv-star[data-bv="pill"],bv-star[data-bv="chip"]').forEach(x => x.remove()); load(); }); } else if (c.acc || c.vel || c.gro) load(); });
  chrome.runtime.onMessage.addListener((m, _s, reply) => { if (m && m.type === 'navigate') { BV.spaNavigate(m.url); reply({ok: true}); } });
  addEventListener('resize', schedule); addEventListener('popstate', schedule);
  load(); try { chrome.runtime.sendMessage({type: 'ensure'}, () => void chrome.runtime.lastError); } catch (e) {}
})();
