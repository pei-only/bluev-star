// 蓝V星图 shared helpers (popup, options, content)
var BV = globalThis.BV || (globalThis.BV = {});
BV.SITE = 'https://pei-only.github.io/bluev-star/';
BV.DATA = BV.SITE + 'data/';
BV.DEFAULTS = {sidebar: true, profile: true, pills: true, chips: true, floating: true, interval: 1440, niches: [], theme: 'auto', sameTab: true};
BV.getSettings = () => new Promise(r => chrome.storage.local.get('settings', o => r(Object.assign({}, BV.DEFAULTS, o.settings || {}))));
BV.setSettings = s => new Promise(r => chrome.storage.local.set({settings: s}, r));
BV.getData = () => new Promise(r => chrome.storage.local.get(['acc', 'vel', 'gro', 'fetchedAt', 'lastError'], r));
BV.refresh = () => new Promise(r => { try { chrome.runtime.sendMessage({type: 'refresh'}, x => { void chrome.runtime.lastError; r(x); }); } catch (e) { r(null); } });
BV.fmt = n => { if (n == null || n === '') return '—'; n = +n; const a = Math.abs(n);
  if (a >= 1e8) return (n / 1e8).toFixed(1).replace(/\.0$/, '') + '亿';
  if (a >= 1e4) return (n / 1e4).toFixed(a >= 1e5 ? 0 : 1).replace(/\.0$/, '') + '万';
  return n.toLocaleString('zh-CN'); };
BV.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
BV.av = (acc, v) => !v ? '' : /^https?:/.test(v) ? v : acc.avpfx + v.replace('~.', '_400x400.');
BV.small = u => (u || '').replace('_400x400.', '_bigger.');
BV.ICON = {'技术AI':'🤖','Web3币圈':'🪙','其他':'✨','财经宏观':'📈','创业出海':'🚀','搞钱路子':'💰','时政评论':'🏛️','生活日常':'☕','新闻快讯搬运':'📰','搞笑meme':'😂','卖服务私域':'🤝','读书知识':'📚','美女擦边':'💃','设计审美':'🎨','情感婚恋':'💞','心理成长':'🌱','旅行':'✈️','玄学星座':'🔮','健身运动':'💪','宠物':'🐾','科技数码':'📱','留学移民':'🎓','游戏动漫':'🎮','海外生活':'🌍','职场':'💼','美食':'🍜','影视音乐':'🎬','育儿教育':'🧸'};
BV.ni = n => (BV.ICON[n] || '✨') + ' ' + (n || '其他');
// account lookup: returns object or null
BV.lookup = (acc, h) => { if (!acc || !h) return null; const r = acc.a[h.toLowerCase()]; if (!r) return null;
  return {handle: r[0], name: r[1] || r[0], niche: acc.niches[r[2]], nicheIdx: r[2], followers: r[3], vtype: acc.vtypes[r[4]], rank: r[5], tags: r[6] || [], avatar: BV.av(acc, r[7]), owner: !!r[8],
    nicheTotal: (acc.niche_counts || [])[r[2]], growth: (acc.growth_by_handle || {})[h.toLowerCase()] || {}}; };
BV.siteLink = h => BV.SITE + '#dir?q=' + encodeURIComponent(h);
BV.ago = iso => { if (!iso) return ''; const m = Math.round((Date.now() - new Date(iso)) / 60000); return m < 1 ? '刚刚' : m < 60 ? m + ' 分钟前' : m < 1440 ? Math.round(m / 60) + ' 小时前' : Math.round(m / 1440) + ' 天前'; };

// Navigate x.com SPA-style in the current tab; fall back to full load.
BV.spaNavigate = (url) => {
  let u; try { u = new URL(url, location.href); } catch (e) { return; }
  if (!/(^|\.)(x|twitter)\.com$/.test(u.hostname) || u.hostname !== location.hostname) { location.assign(u.href); return; }
  if (u.pathname + u.search === location.pathname + location.search) return;
  const col = document.querySelector('[data-testid="primaryColumn"]'); const before = col && col.firstElementChild;
  const sig = col ? col.textContent.length + '|' + (before && before.outerHTML.length) : '';
  try { history.pushState({}, '', u.pathname + u.search + u.hash); window.dispatchEvent(new PopStateEvent('popstate', {state: history.state})); } catch (e) { location.assign(u.href); return; }
  const target = u.pathname;
  setTimeout(() => { if (location.pathname !== target) return; const c = document.querySelector('[data-testid="primaryColumn"]');
    const now = c ? c.textContent.length + '|' + (c.firstElementChild && c.firstElementChild.outerHTML.length) : '';
    if (!c || now === sig) location.assign(u.href); }, 1600);
};

// ---------- v1.2.0: freshness, ranks, favorites, error counter ----------
BV.OWNER = 'Pei33f';
BV.hhmm = t => { const d = new Date(t); if (isNaN(d)) return ''; const p = n => String(n).padStart(2, '0');
  const sameDay = new Date().toDateString() === d.toDateString(); return (sameDay ? '' : (d.getMonth() + 1) + '月' + d.getDate() + '日 ') + p(d.getHours()) + ':' + p(d.getMinutes()); };
// stale rule (Asia/Shanghai): >2h old, except quiet hours 23:00–09:30 when last sample is at/after 22:30 of that night
BV.isStale = (gen, now) => { const t = new Date(gen).getTime(); if (isNaN(t)) return false; return now - t > 36 * 3600e3;
  const SH = 8 * 3600e3, d = new Date(now + SH), mins = d.getUTCHours() * 60 + d.getUTCMinutes();
  if (mins >= 23 * 60 || mins < 9 * 60 + 30) { const day = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) - SH; // 00:00 SH today, as epoch
    const night = (mins >= 23 * 60 ? day : day - 864e5) + 22.5 * 3600e3; if (t >= night) return false; }
  return true; };
// returns {text, stale, failed, html}
BV.fresh = D => {
  if (!D || !D.acc) return {text: D && D.lastError ? '数据加载失败' : '正在加载…', stale: false, failed: !!(D && D.lastError)};
  const gen = (D.gro && D.gro.generated_at) || D.acc.generated_at || D.fetchedAt;
  const stale = BV.isStale(gen, BV.now ? BV.now() : Date.now());
  const failed = !!D.lastError;
  let text = '数据更新于 ' + BV.hhmm(gen);
  if (failed) text = '刷新失败 · 显示 ' + BV.hhmm(D.fetchedAt || gen) + ' 成功获取的数据';
  return {text, stale, failed, warn: stale ? '数据可能已过时' : ''};
};
BV.freshHTML = D => { const f = BV.fresh(D); return `<span class="fr${f.failed ? ' bad' : ''}">🕒 ${BV.esc(f.text)}</span>${f.warn ? `<span class="fw">⚠️ ${f.warn}</span>` : ''}`; };
// rank of a handle in every board
BV.ranks = (D, h) => { const out = []; if (!h) return out; h = h.toLowerCase();
  const W = {'30m': '30分钟', '1h': '1小时', '3h': '3小时', '5h': '5小时'};
  const vb = {}; // v1.3.0: velocity hidden (daily updates)
  for (const k of Object.keys(W)) { const b = vb[k]; if (!b) continue; const s = b.slice().sort((x, y) => y.dviews - x.dviews); const i = s.findIndex(r => (r.handle || '').toLowerCase() === h); if (i >= 0) out.push({board: '涨速 ' + W[k], rank: i + 1, total: s.length}); }
  const gb = (D.gro && D.gro.boards) || {};
  for (const k of ['3d', '5d', '10d', '15d', '30d']) { const b = gb[k]; if (!b) continue; const i = b.findIndex(r => (r.handle || '').toLowerCase() === h); if (i >= 0) out.push({board: '涨粉 ' + k.replace('d', '日'), rank: i + 1, total: b.length}); }
  return out; };
BV.search = (D, q, lim) => { if (!D.acc || !q) return []; q = q.trim().toLowerCase().replace(/^@/, ''); if (!q) return [];
  const ex = BV.lookup(D.acc, q); const res = ex ? [ex] : [];
  for (const k in D.acc.a) { if (res.length >= (lim || 5)) break; if (ex && k === q) continue; const r = D.acc.a[k]; if (k.includes(q) || (r[1] || '').toLowerCase().includes(q)) res.push(BV.lookup(D.acc, k)); }
  return res; };
BV.getFavs = () => new Promise(r => chrome.storage.local.get('favs', o => r(o.favs || [])));
BV.toggleFav = async h => { h = h.toLowerCase(); const f = await BV.getFavs(); const i = f.indexOf(h); if (i >= 0) f.splice(i, 1); else f.unshift(h); await new Promise(r => chrome.storage.local.set({favs: f}, r)); return i < 0; };
let _errT = 0;
BV.logErr = (where, e) => { try { console.debug('[蓝V星图]', where, e); if (Date.now() - _errT < 2000) return; _errT = Date.now();
  chrome.storage.local.get('errs', o => { const x = o.errs || {count: 0}; x.count++; x.last = where + ': ' + String(e && e.message || e).slice(0, 160); x.at = Date.now(); chrome.storage.local.set({errs: x}); }); } catch (_) {} };
BV.q = (root, sels) => { for (const s of sels) { try { const el = root.querySelector(s); if (el) return el; } catch (_) {} } return null; };
BV.qa = (root, sels) => { for (const s of sels) { try { const l = root.querySelectorAll(s); if (l.length) return l; } catch (_) {} } return []; };
// HTML for one account result (search / favorites); uses board CSS classes
BV.accHTML = (D, a, fav) => { const rk = BV.ranks(D, a.handle), g = a.growth || {};
  const gs = ['3d', '5d', '10d', '15d', '30d'].filter(k => g[k] != null).map(k => `<span class="chip up">${k.replace('d', '日')} +${BV.fmt(g[k])}</span>`).join('');
  return `<div class="acc"><div class="row" data-href="https://x.com/${encodeURIComponent(a.handle)}" title="打开主页">${a.avatar ? `<img class="av" src="${BV.esc(BV.small(a.avatar))}" loading="lazy" referrerpolicy="no-referrer">` : '<div class="av"></div>'}<div class="mid"><div class="nm"><b>${BV.esc(a.name)}</b><span class="hn">@${BV.esc(a.handle)}</span>${a.owner ? '<span class="chip own">⭐ 站长</span>' : ''}</div>
  <div class="meta"><span class="chip">${BV.esc(BV.ni(a.niche))}</span><span class="chip">方向排名 #${a.rank}${a.nicheTotal ? '/' + a.nicheTotal : ''}</span><span>粉丝 ${BV.fmt(a.followers)}</span></div>
  <div class="meta">${rk.length ? rk.map(r => `<span class="chip hot">${r.board} #${r.rank}</span>`).join('') : '<span class="chip">暂未上涨速/涨粉榜</span>'}${gs || '<span class="chip">涨粉数据积累中</span>'}</div></div>
  <button class="star${fav ? ' on' : ''}" data-fav="${BV.esc(a.handle)}" title="${fav ? '取消收藏' : '收藏'}">${fav ? '★' : '☆'}</button></div></div>`; };
BV.ACC_CSS = `.srch{display:flex;gap:6px;padding:8px 12px 0}.srch input{flex:1;min-width:0;border:1px solid var(--line);background:var(--soft);color:var(--fg);border-radius:10px;padding:6px 10px;font:inherit;font-size:12px;outline:none}.srch input:focus{border-color:var(--acc)}
.srch .pill{flex:none}.sres{padding:2px 6px 0}.sres:empty{display:none}
.acc .row{align-items:center}.star{flex:none;border:0;background:transparent;font-size:18px;cursor:pointer;color:var(--mut);padding:2px 4px;line-height:1}.star.on{color:#f5a524}
.chip.hot{background:rgba(255,90,54,.12);color:#e8462f}.chip.up{color:#e8462f}.chip.own{background:rgba(245,165,36,.15);color:#b7791f}
.fresh{display:flex;gap:6px;flex-wrap:wrap;padding:0 14px 2px;font-size:11px;color:var(--mut)}.fr.bad{color:#e8462f}.fw{color:#b7791f;background:rgba(245,165,36,.14);border-radius:999px;padding:0 7px}`;
